"""Automation package."""
